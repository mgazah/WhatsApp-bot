/**
 * Broadcast Command - Send message to all chats
 */

module.exports = {
  name: 'broadcast',
  aliases: ['bc'],
  category: 'owner',
  description: 'Broadcast message to all chats',
  usage: '.broadcast <message>',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      if (args.length === 0) {
        return extra.reply('❌ Usage: .broadcast <message>\n\nExample: .broadcast Hello everyone!');
      }
      const message = args.join(' ');
      const chats = await sock.groupFetchAllParticipating();
      const groups = Object.values(chats);
      let success = 0;
      let failed = 0;
      for (const group of groups) {
        try {
          await sock.sendMessage(group.id, {
            text: `\n${message}\n\n> ©June`
          });
          success++;
        } catch (e) {
          failed++;
        }
      }
      await extra.reply(`✅ Broadcast complete!\n\n✅ Success: ${success}\n❌ Failed: ${failed}`);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};